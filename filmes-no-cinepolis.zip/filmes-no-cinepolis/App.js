import React from 'react';
import { StyleSheet, View } from 'react-native';
import AssetExample from './components/AssetExample';

export default function App() {
  return (
    <View style={styles.container}>
      <AssetExample />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#00008B',
    padding: 20,
  },
});