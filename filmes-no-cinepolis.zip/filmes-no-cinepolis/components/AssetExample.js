import React, { useState } from 'react';
import { View, Text, FlatList, TextInput, Button, StyleSheet } from 'react-native';
import { Card } from 'react-native-paper';
import Icon from 'react-native-vector-icons/FontAwesome';

const MovieList = () => {
  const [moviesToWatch, setMoviesToWatch] = useState([
    { title: 'Spider-Man: Homecoming', genre: 'Ação', rating: 3 },
    { title: 'Mean Girls', genre: 'Comédia', rating: 2.5 },
    { title: 'The Silence of the Lambs', genre: 'Drama', rating: 4 },
    { title: 'Parasite', genre: 'Suspense/Mistério', rating: 5 },
  ]);
  const [moviesWatched, setMoviesWatched] = useState([]);
  const [newMovie, setNewMovie] = useState({ title: '', genre: '', rating: 0 });

  const addMovie = () => {
    if (isValidMovie(newMovie)) {
      setMoviesToWatch([...moviesToWatch, { ...newMovie }]);
      setNewMovie({ title: '', genre: '', rating: 0 });
    }
  };

  const isValidMovie = (movie) => {
    const { title, genre, rating } = movie;
    return title.trim() !== '' && genre.trim() !== '' && rating >= 0 && rating <= 10;
  };

  const deleteMovie = (index, isWatched) => {
    if (isWatched) {
      const updatedWatchedMovies = [...moviesWatched];
      updatedWatchedMovies.splice(index, 1);
      setMoviesWatched(updatedWatchedMovies);
    } else {
      const updatedToWatchMovies = [...moviesToWatch];
      updatedToWatchMovies.splice(index, 1);
      setMoviesToWatch(updatedToWatchMovies);
    }
  };

  const renderStars = (rating) => {
    const stars = [];
    for (let i = 1; i <= 5; i++) {
      stars.push(
        <Icon
          key={i}
          name={i <= rating ? 'star' : 'star-o'}
          size={30}
          color={i <= rating ? '#FFD700' : '#ccc'}
        />
      );
    }
    return stars;
  };

  const markAsWatched = (index) => {
    const movieToMove = moviesToWatch[index];
    setMoviesWatched([...moviesWatched, movieToMove]);
    deleteMovie(index, false);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.logo}> 🟡 Cinépolis 🟡 </Text>
      <View style={styles.contentContainer}>
        <Card style={styles.card}>
          <Card.Content>
            <Text style={styles.title}>Lista de Filmes</Text>
            <TextInput
              placeholder="Título do Filme"
              onChangeText={(text) => setNewMovie({ ...newMovie, title: text })}
              style={styles.input}
              placeholderTextColor="#00008B"
              value={newMovie.title}
            />
            <TextInput
              placeholder="Gênero do Filme"
              onChangeText={(text) => setNewMovie({ ...newMovie, genre: text })}
              style={styles.input}
              placeholderTextColor="#00008B"
              value={newMovie.genre}
            />
            <View style={styles.ratingContainer}>
              <Text style={styles.ratingLabel}>Avaliação do Filme:</Text>
              {renderStars(newMovie.rating)}
            </View>
            <TextInput
              placeholder="Nota (0-5)"
              value={newMovie.rating.toString()}
              onChangeText={(text) => {
                const rating = parseFloat(text);
                setNewMovie({ ...newMovie, rating: isNaN(rating) ? 0 : rating });
              }}
              style={styles.input}
              keyboardType="numeric"
              placeholderTextColor="#00008B"
            />
            <Button title="Adicionar Filme" onPress={addMovie} color="#007BFF" />
          </Card.Content>
        </Card>

        <Text style={styles.subHeader}>Filmes para Assistir:</Text>
        <FlatList
          data={moviesToWatch}
          keyExtractor={(item, index) => index.toString()}
          renderItem={({ item, index }) => (
            <Card style={styles.movieCard}>
              <Card.Content>
                <Text style={styles.movieTitle}>Título: {item.title}</Text>
                <Text style={styles.movieInfo}>Gênero: {item.genre}</Text>
                <View style={styles.ratingContainer}>
                  <Text style={styles.ratingLabel}>Avaliação:</Text>
                  {renderStars(item.rating)}
                </View>
                <View style={styles.buttonContainer}>
                  <Button title="Assistir" onPress={() => markAsWatched(index)} color="#00FF00" />
                  <Button
                    title="Excluir"
                    onPress={() => deleteMovie(index, false)}
                    color="#FF4500"
                  />
                </View>
              </Card.Content>
            </Card>
          )}
        />

        <Text style={styles.subHeader}>Assistidos:</Text>
        <FlatList
          data={moviesWatched}
          keyExtractor={(item, index) => index.toString()}
          renderItem={({ item, index }) => (
            <Card style={styles.movieCard}>
              <Card.Content>
                <Text style={styles.movieTitle}>Título: {item.title}</Text>
                <Text style={styles.movieInfo}>Gênero: {item.genre}</Text>
                <View style={styles.ratingContainer}>
                  <Text style={styles.ratingLabel}>Avaliação:</Text>
                  {renderStars(item.rating)}
                </View>
                <View style={styles.buttonContainer}>
                  <Button
                    title="Excluir"
                    onPress={() => deleteMovie(index, true)}
                    color="#FF4500"
                  />
                </View>
              </Card.Content>
            </Card>
          )}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#00008B',
    padding: 20,
    justifyContent: 'center',
  },
  contentContainer: {
    flex: 1,
  },
  logo: {
    fontSize: 30,
    fontWeight: 'bold',
    marginBottom: 40,
    color: '#FFD700',
    textAlign: 'center',
  },
  title: {
    fontSize: 30,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#00008B',
    textAlign: 'center',
  },
  card: {
    marginBottom: 20,
  },
  movieCard: {
    marginBottom: 20,
    borderColor: '#FFD700',
    borderWidth: 1,
    borderRadius: 10,
  },
  subHeader: {
    fontSize: 24,
    marginBottom: 10,
    color: '#FFD700',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  input: {
    marginBottom: 10,
    padding: 10,
    borderColor: '#FFD700',
    borderWidth: 1,
    borderRadius: 16,
    color: '#00008B',
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  ratingLabel: {
    marginRight: 10,
    color: '#00008B',
  },
  movieTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#00008B',
  },
  movieInfo: {
    color: '#00008B',
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
});

export default MovieList;
